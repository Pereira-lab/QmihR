/*
 *  Copyright 2017, Bruno Cavadas <bcavadas@ipatimup.pt>
 * 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 * 
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 * 
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 *  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 *  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 *  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */

#include <stdio.h>
#include <inttypes.h>
#include <zlib.h>
#include "kseq.h"
#include "kbtree.h"

typedef struct {
  char *name, *seq, *qual;
} elem_t;

#define elem_cmp(a, b) (strcmp((a).name, (b).name))
KBTREE_INIT(str, elem_t, elem_cmp)
KSEQ_INIT(gzFile, gzread)

void allocateData(elem_t *t, char *name, char *seq, char *qual) {
  t->name = (char*) malloc( sizeof(char)*(strlen(name)+1) );
  t->seq  = (char*) malloc( sizeof(char)*(strlen(seq)+1) );
  t->qual = (char*) malloc( sizeof(char)*(strlen(qual)+1) );

  strcpy(t->name, name);
  strcpy(t->seq, seq);
  strcpy(t->qual, qual);
}

int main(int argc, char **argv) {
  if (argc < 4)
    return fprintf(stderr, "Usage: %s <foward.fastq.gz> <reverse.fastq.gz> <OutputName>\n", argv[0]);

  gzFile foward, reverse;
  kseq_t *seqFoward, *seqReverse;

  if (!(foward= gzopen(argv[1], "r")))
    return fprintf(stderr, "ERROR: Input Foward file not found\n");

  if (!(reverse= gzopen(argv[2], "r")))
    return fprintf(stderr, "ERROR: Input Reverse file not found\n");

  kbtree_t(str) *b;
  kbitr_t itr;
  elem_t *p, t;
  int lf, lr;
  char *c;

  b = kb_init(str, KB_DEFAULT_SIZE);
  seqFoward= kseq_init(foward);
  seqReverse= kseq_init(reverse);

  char *outFilename1= malloc(strlen(argv[3]) + 14); /* plus 14 to append sync_1.fastq */
  char *outFilename2= malloc(strlen(argv[3]) + 14); /* plus 14 to append sync_2.fastq */
  sprintf(outFilename1, "%s_sync_1.fastq", argv[3]);
  sprintf(outFilename2, "%s_sync_2.fastq", argv[3]);
  
  FILE *out1= fopen(outFilename1, "w");
  FILE *out2= fopen(outFilename2, "w");
  
  for (;;) {
    if ((lf = kseq_read(seqFoward)) >= 0) {
      if  ((c= strstr(seqFoward->name.s, "/1"))) *c= '\0';
      allocateData(&t, seqFoward->name.s, seqFoward->seq.s, seqFoward->qual.s);
      p= kb_getp(str, b, &t);
      if (!p) kb_putp(str, b, &t);
      else {
	fprintf(out1, "@%s\n%s\n+\n%s\n", t.name, t.seq, t.qual); // Foward
	fprintf(out2, "@%s\n%s\n+\n%s\n", p->name, p->seq, p->qual);  // Reverse
	free(t.name), free(t.seq), free(t.qual);
	t= *p;
	kb_del(str, b, *p);
	free(t.name), free(t.seq), free(t.qual);
      }
    }
    //REVERSE
    if ((lr = kseq_read(seqReverse)) >= 0) {
      if  ((c= strstr(seqReverse->name.s, "/2"))) *c= '\0';
      allocateData(&t, seqReverse->name.s, seqReverse->seq.s, seqReverse->qual.s);
      p= kb_getp(str, b, &t);
      if (!p) kb_putp(str, b, &t);
      else {
	fprintf(out1, "@%s\n%s\n+\n%s\n", p->name, p->seq, p->qual); // Foward
	fprintf(out2, "@%s\n%s\n+\n%s\n", t.name, t.seq, t.qual); // Reverse
	free(t.name), free(t.seq), free(t.qual);
	t= *p;
	kb_del(str, b, *p);
	free(t.name), free(t.seq), free(t.qual);
      }
    }
    if (lf < 0 && lr < 0) break;
  }

  // ordered tree traversal
  kb_itr_first(str, b, &itr); // get an iterator pointing to the first
  for (; kb_itr_valid(&itr); kb_itr_next(str, b, &itr)) { // move on
    p = &kb_itr_key(elem_t, &itr);
    free(p->name), free(p->seq), free(p->qual);
  }
  
  kb_destroy(str, b);
  fclose(out1); fclose(out2);
  kseq_destroy(seqFoward); kseq_destroy(seqReverse);
  gzclose(foward); gzclose(reverse);
  return 0;
}
